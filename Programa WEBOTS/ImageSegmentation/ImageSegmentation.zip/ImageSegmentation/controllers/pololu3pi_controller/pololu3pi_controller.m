% =================================================================
% MT3006 - LABORATORIO 3: Control basado en visión
% -----------------------------------------------------------------
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat, con un módulo
% OpenMV Cam montado encima. Tome en consideración, sin embargo, que 
% puede que existan ciertas discrepancias en términos de escalamiento 
% para las ganancias de los controladores, ya que la física del robot 
% se aproximó de manera sencilla.
% =================================================================
function pololu3pi_controller
addpath('robotat'); % para poder emplear las funciones del Robotat
rng('shuffle'); % Activar para garantizar aleatoridad en AG

TIME_STEP = 64;

% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');
figure(1);
camera = wb_robot_get_device('camera');

% Se configuran y activan el GPS, la brújula y la cámara
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);
wb_camera_enable(camera, 20);



% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
v_max = 800 / 2;

% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 0;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

% - - - - - - Modificación realizada - - - - - - - -- - - - 
% Modificado por: Jose Pablo Petion Rivas
% La imagen del objeto que queremos seguir o identificar en la simulación
ref_img = imread('ball.png');
% Llamamos al algoritmo genético para que estime los mejores filtros
limites = image_seg_GA(ref_img)
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1
  % Se obtiene y visualiza la imagen actual de la cámara
  % *** COMPLETAR ***
  % OJO: para utilizar alguna función que haya desarrollado con 
  % las herramientas de MATLAB, como la Color Thresholder, basta
  % con que añada la misma a la carpeta 
  % ...\wbtlab3\controllers\pololu3pi_controller
  figure(2);
  rgb = wb_camera_get_image(camera);
  [BW, RGB_MASKED] = Ball_mask(rgb, limites);
  BW_FILL = imfill(BW, 'holes');
  [BW_out, Properties] = filterRegions(BW_FILL);
  imshow(BW_out);
  if isempty(Properties) == 0
      c_x  = Properties(1).Centroid(1);
      c_y  = Properties(1).Centroid(2);
      area = max(Properties(1).Area);
  end

  % Se calcula el controlador (vctrl está en mm/s para ser
  % congruente con las dimensiones del robot)
  % *** COMPLETAR ***
  kv = 1;
  kw = 0.05;
  
  if isempty(Properties) == 0
    vctrl = -kv*(area-0.03*128*128);
    wctrl = -kw*(c_x-64);
  else
    vctrl = 0;
    wctrl = 0.5;   
  end
  
  % Se mapea del uniciclo de regreso al robot diferencial
  v_left = (vctrl - wheel_distance * wctrl) / wheel_radius; 
  v_right = (vctrl + wheel_distance * wctrl) / wheel_radius;
  
  % Cambio a rpms, sólo para ser congruente con el manejo del 
  % robot real
  v_left = rads2rpm(v_left);
  v_right = rads2rpm(v_right); 

  % Se envían las velocidades a los motores de las ruedas (debe
  % garantizarse que estas no superan el valor máximo)
  wb_motor_set_velocity(left_motor, -rpm2rads(velsat(v_left)));
  wb_motor_set_velocity(right_motor, -rpm2rads(velsat(v_right)));

  % Flush para gráficos
  drawnow;

end

% cleanup code goes here: write data to files, etc.
