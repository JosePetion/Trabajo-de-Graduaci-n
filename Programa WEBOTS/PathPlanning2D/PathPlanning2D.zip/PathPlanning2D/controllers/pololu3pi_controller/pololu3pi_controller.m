% =================================================================
%                     MT3005 - LABORATORIO 12: 
% Planificación de movimiento para robots móviles con ruedas.
% -----------------------------------------------------------------
% NOTA: se asume que ya tiene funcionando correctamente el 
% controlador PID con acercamiento exponencial.
%
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat, con un 
% conjunto de obstáculos representados por markers sobre la 
% plataforma (cilindros dentro de la simulación). La idea es crear
% un mapa de la situación en forma de un occupancy grid y aplicar
% el método D* (de la Robotics Toolbox de Peter Corke) para 
% resolver el laberinto. Finalmente se empleará el controlador PID
% para hacer que el robot ejecute el recorrido encontrado.
% =================================================================
function pololu3pi_controller
% este comando permite modificar la semilla para valores aleatorios
% en nuestro algoritmo genético, cambio importante.
rng('shuffle');
% Para poder emplear las funciones del Robotat (de ser necesario)
addpath('robotat'); 

TIME_STEP = 64; % tiempo de simulación en ms

% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');

% Se configuran y activan el GPS y la brújula
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);

% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
v_max = 800 / 2;

% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 10;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

% -----------------------------------------------------------------
% DEFINICIÓN DE VARIABLES E INICIALIZACIÓN DEL CONTROLADOR
% -----------------------------------------------------------------
% controlador lineal de pose
k_rho = 175;
k_alpha = 0.2; 
k_beta = -0.00150;
% -----------------------------------------------------------------
% DEFINICIÓN DE OBSTÁCULOS Y CREACIÓN DEL MAPA
% -----------------------------------------------------------------
% Se definen uno por uno los obstáculos, en caso de querer deshabilitar
% alguno igualar a un vector vacío
obs1 = [0.5, 0.5];
obs2 = [-0.5, 0.5];
obs3 = [0.5, -0.5];
obs4 = [-0.5, -0.5];
obs5 = [1, 1];
obs6 = [-1 , 1];
obs7 = [1, -1];
obs8 = [-1, -1];
obs9 = [1.25, 1.25];
obs10 = [-1.25, -1.25];

% Array de obstáculos
obs = [obs1; obs2; obs3; obs4; obs5; obs6; obs7; obs8; obs9; obs10];

% Se guarda la posición de los obstáculos (esto se hace para poder
% visualizar el cambio en la simulación)
save('../obstacles.mat', "obs");

% Se emplea el array de obstáculos para crear y visualizar el mapa (bordes
% de plataforma + obstáculos) como un occupancy grid
MapSize = 5; % Tamaño del mapa
Ps = [-2.25, -2.25]; % punto de inicio
Pg = [2.3, 2.3]; % punto de meta
Pop_size = 30; % tamaño de la población
n_gen = 20; % Generaciónes a crear (iteraciones)
n_points = 5; % numero de puntos intermedios en el mapa 
radius = 0.08; % radio de los obstaculos
robot_radius = 0.06;
% -----------------------------------------------------------------
% PLANIFICACIÓN DE MOVIMIENTO
% -----------------------------------------------------------------
% Emplee las funciones de la Robotics Toolbox de Peter Corke junto 
% con el documento Navigation-PC para encontrar una ruta óptima 
% entre la posición actual del robot y la meta establecida mediante 
% el algoritmo D*. Tome en consideración lo siguiente:
% a) Debe efectuarse un aumento de mapa de 8 celdas (8 cm), que 
% corresponde aproximadamente al radio del robot (junto con el marker).
% b) Deben transformarse las coordenadas reales (Robotat y/o Webots) 
% del robot y la meta a las coordenadas del mapa (en cm, el origen 
% se encuentra en la esquina superior izquierda, la dirección/signo 
% del eje y coincide pero la del eje x está al revés).
% c) Note que el Toolbox hace una visualización "rara" del mapa, pero
% verifique que este corresponde al mismo que se visualizó en la 
% sección anterior (debería ser una visualización reflejada con 
% respecto al eje horizontal).
% d) Luego de obtener la ruta óptima, esta debe transformarse de 
% regreso a las coordenadas reales del Robotat y/o Webots. En 
% esencia debe deshacerse lo que se hizo en la consideración b). 
% Parámetros de simulación
% Modificar a preferencia
% transformamos a cm como esta configurado nuestro algoritmo genetico
% - - - - - NO MODIFICAR - - - - - - - -
MapSize = MapSize * 100;
obs = obs*100 + (MapSize/2);
Ps = round(Ps*100 + (MapSize/2));
Pg = round(Pg*100 + (MapSize/2));
radius = radius*100;
robot_radius = robot_radius*100;
path = pathplanningGA(MapSize, obs, (radius+robot_radius), Ps, Pg, Pop_size, n_gen, n_points);
%  - - - - - - - - - - - - - - - - - - -
% Ahora hacemos lo contrario con nuestro vector de trayectoria
% lo pasamos a metros
% - - NO MODIFICAR - - - 
path = (path - (MapSize/2)) * (1/100);
% - - - - - - - - - -
k = 1; 
% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1
    % Se obtiene la posición y orientación actual del robot
    pos = wb_gps_get_values(gps);
    mag = wb_compass_get_values(compass);
    posx = pos(1); posy = pos(2);
    bearing = atan2d(mag(2), mag(1)) - 90;
    theta = atan2d(sind(-bearing), cosd(-bearing));
    xg = path(k,1);
    yg = path(k,2);
    
    % -----------------------------------------------------------------
    % CONTROL (LAB11, PID CON ACERCAMIENTO EXPONENCIAL) MÁS EJECUCIÓN 
    % DE PLANIFICACIÓN
    % -----------------------------------------------------------------
    % Para la ejecución de la planificación, se le recomienda 
    % implementar una estrategia de pursuit para el controlador, en 
    % donde (xg, yg) sea un punto dentro de la ruta óptima y este valor 
    % se vaya actualizando conforme el robot se acerque al punto. Es 
    % decir, puede emplearse una condición sobre el error de posición 
    % para actualizar el valor de (xg, yg) hasta acabarse los puntos 
    % dentro de la ruta.
    e = [xg - posx; yg - posy];    
    rho = norm(e);
    alpha = -theta + atan2d(e(2), e(1));
    alpha = atan2d(sind(alpha), cosd(alpha));
    beta = -theta - alpha;
    
    if rho < 0.1
      k = k+1;
      if k > length(path)
        k = length(path);
      end
    end
    
    vctrl = k_rho*rho;
    uctrl = k_alpha*alpha + k_beta*beta;
    
    v_left = (vctrl-wheel_distance*uctrl)/wheel_radius;
    v_right = (vctrl+wheel_distance*uctrl)/wheel_radius;
    
    v_left = rads2rpm(v_left);
    v_right = rads2rpm(v_right);
    
    % Se mapea del uniciclo de regreso al robot diferencial.
    % OJO: los resultados de estas fórmulas están en rad/s, DEBEN
    % cambiarse a rpm (usar la función auxiliar de conversión)
  
    % Se envían las velocidades a los motores de las ruedas (debe
    % garantizarse que estas no superan el valor máximo)
    wb_motor_set_velocity(left_motor, -rpm2rads(velsat(v_left)));
    wb_motor_set_velocity(right_motor, -rpm2rads(velsat(v_right)));
    
    %pause(0.1);
    % Flush para gráficos
    drawnow;
end

% cleanup code goes here: write data to files, etc.
